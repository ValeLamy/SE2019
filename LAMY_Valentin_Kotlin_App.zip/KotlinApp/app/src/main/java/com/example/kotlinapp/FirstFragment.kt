package com.example.kotlinapp

import android.os.Bundle
import androidx.fragment.app.Fragment
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import android.widget.TextView
import android.widget.Toast
import androidx.navigation.fragment.findNavController

/**
 * A simple [Fragment] subclass as the default destination in the navigation.
 */
class FirstFragment : Fragment() {

    override fun onCreateView(
            inflater: LayoutInflater, container: ViewGroup?,
            savedInstanceState: Bundle?
    ): View? {
        // Inflate the layout for this fragment
        return inflater.inflate(R.layout.fragment_first, container, false)
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        // find button "Random" by its id and set a click listener to switch displayed fragment
        view.findViewById<Button>(R.id.random_button).setOnClickListener {
            val showCountTextView = view.findViewById<TextView>(R.id.textview_first)
            val currentCount = showCountTextView.text.toString().toInt()
            val action = FirstFragmentDirections.actionFirstFragmentToSecondFragment(currentCount)
            findNavController().navigate(action)
        }

        // find button "Reset" by its id and set a click listener to reset displayed value
        view.findViewById<Button>(R.id.reset_button).setOnClickListener {
            resetMe(view)
        }

        // find button "Count" by its id and set a click listener to increment displayed value
        view.findViewById<Button>(R.id.count_button).setOnClickListener {
            countMe(view)
        }
    }

    // function to increment a value one by one
    fun countMe (view: View) {
        // detect text view by its id "textview_first"
        val showCountTextView = view.findViewById<TextView>(R.id.textview_first)
        // get text view value
        val countString = showCountTextView.text.toString()
        // convert value to number and increment it
        var count: Int = Integer.parseInt(countString)
        count++
        // display new value in the text view
        showCountTextView.text = count.toString()
    }

    // function to reset displayed value to 0
    fun resetMe (view: View) {
        // detect text view by its id "textview_first"
        val showCountTextView = view.findViewById<TextView>(R.id.textview_first)
        // change displayed value to 0
        showCountTextView.text = "0"
    }
}
